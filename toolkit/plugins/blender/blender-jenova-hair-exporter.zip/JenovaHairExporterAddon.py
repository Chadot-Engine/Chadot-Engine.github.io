bl_info = {'name': 'Jenova Hair Exporter', 'author': 'MemarDesign™ LLC.', 'version': (1, 1, 0), 'blender': (3, 5, 0), 'location': 'File > Export > Jenova Hair Data', 'description': 'Export selected Hair Curves or Hair Meshes to Jenova Hair Format', 'category': 'Import-Export'}
import bpy
import struct
import numpy as np
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, IntProperty, FloatProperty

def I14(I32, I17, segments=20, scale=10.0):
    I26 = segments + 1
    I10 = I32.data
    I30 = len(I10.points)
    I29 = len(I10.curve_offset_data)
    I31 = I29 - 1
    if I31 <= 0 or I30 == 0: raise ValueError('No Hair Curves Found on This Object')
    I37 = np.empty(I30 * 3, dtype=np.float32)
    I10.points.foreach_get('position', I37)
    I37 = I37.reshape(-1, 3).astype(np.float64)
    I33 = np.empty(I29, dtype=np.int32)
    I10.curve_offset_data.foreach_get('value', I33)
    I40 = np.zeros((I31, I26, 3), dtype=np.float32)
    I24 = np.zeros((I31, I26, 3), dtype=np.float32)
    I35 = np.zeros((I31, I26, 3), dtype=np.float32)
    for I22 in range(I31):
        I45 = I33[I22]
        I12 = I33[I22 + 1]
        I46 = I37[I45:I12]
        if len(I46) == 0:
            I40[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            I24[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            I35[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            continue
        I11 = np.linalg.norm(np.diff(I46, axis=0), axis=1)
        I52 = np.concatenate(([True], I11 > 1e-06))
        I46 = I46[I52]
        if len(I46) < 2:
            I36 = I46[0]
            I40[I22] = np.tile(I36, (I26, 1))
            I24[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            I35[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            continue
        I11 = np.linalg.norm(np.diff(I46, axis=0), axis=1)
        I9 = np.concatenate(([0.0], np.cumsum(I11)))
        I50 = I9[-1]
        if I50 < 1e-06:
            I40[I22] = np.tile(I46[0], (I26, 1))
            I24[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            I35[I22] = np.tile([0.0, 0.0, 0.0], (I26, 1))
            continue
        I47 = np.linspace(0, I50, I26)
        I39 = np.zeros((I26, 3), dtype=np.float64)
        for I3 in range(3):
            I39[:, I3] = np.interp(I47, I9, I46[:, I3])
        I34 = np.zeros((I26, 3), dtype=np.float64)
        I23 = np.zeros((I26, 3), dtype=np.float64)
        I34[0] = I39[0] + (I39[1] - I39[0]) / 3.0
        I23[0] = I39[0] - (I39[1] - I39[0]) / 3.0
        for I25 in range(1, I26 - 1):
            I20 = (I39[I25 + 1] - I39[I25 - 1]) / 6.0
            if np.linalg.norm(I20) < 1e-08:
                I20 = np.array([1e-05, 1e-05, 1e-05])
            I34[I25] = I39[I25] + I20
            I23[I25] = I39[I25] - I20
        I34[-1] = I39[-1] + (I39[-1] - I39[-2]) / 3.0
        I23[-1] = I39[-1] - (I39[-1] - I39[-2]) / 3.0
        I40[I22] = I39 * scale
        I24[I22] = I23 * scale
        I35[I22] = I34 * scale
    I49 = I31 * I26
    I2 = b'JNVHAIR@'
    I0 = (1.0, 1.0, 1.0, 1.0)
    I21 = struct.pack('<8s I 4f I 2B 30s', I2, I31, *I0, I49, 1, 0, b'\x00' * 30)
    I7 = np.full(I31, I26, dtype=np.int32)
    I27 = np.empty((I49, 9), dtype=np.float32)
    I27[:, 0:3] = I40.reshape(-1, 3)
    I27[:, 3:6] = I24.reshape(-1, 3)
    I27[:, 6:9] = I35.reshape(-1, 3)
    with open(I17, 'wb') as I15:
        I15.write(I21)
        I15.write(I7.tobytes(order='C'))
        I15.write(I27.tobytes(order='C'))

class I1(bpy.types.Operator, ExportHelper):
    """Export selected Hair Curves or Hair Meshes to Jenova Hair Format"""
    bl_idname = 'export_scene.jnvhair'
    bl_label = 'Export Jenova Hair'
    filename_ext = '.jnvhair'
    filter_glob: StringProperty(default='*.jnvhair', options={'HIDDEN'}, maxlen=255)
    segment_count: IntProperty(name='Segments', description='Number of segments per hair strand.', default=20, min=1)
    global_scale: FloatProperty(name='Scale', description='Global hair data scale. Blender : 10.0 / 3ds Max : 1.0', default=10.0, min=0.0001)

    def execute(I44, I8):
        I32 = I8.active_object
        if not I32:
            I44.report({'ERROR'}, 'No Active Object Selected')
            return {'CANCELLED'}
        I48 = None
        try:
            if I32.type == 'CURVES':
                I14(I32, I44.filepath, segments=I44.segment_count, scale=I44.global_scale)
                I44.report({'INFO'}, f'Exported to {I44.filepath}')
            elif I32.type == 'MESH':
                I48 = I32.copy()
                I48.data = I32.data.copy()
                I8.collection.objects.link(I48)
                bpy.ops.object.select_all(action='DESELECT')
                I48.select_set(True)
                I8.view_layer.objects.active = I48
                if I8.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.convert(target='CURVES')
                if I48.type == 'CURVES':
                    I14(I48, I44.filepath, segments=I44.segment_count, scale=I44.global_scale)
                    I44.report({'INFO'}, f'Hair Data Exported to {I44.filepath}')
                else:
                    I44.report({'ERROR'}, 'Conversion Failed.')
                    return {'CANCELLED'}
            else:
                I44.report({'ERROR'}, 'Must be a Hair Curves or Mesh Object!')
                return {'CANCELLED'}
        except Exception as e:
            I44.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        finally:
            if I48:
                bpy.data.objects.remove(I48, do_unlink=True)
                bpy.ops.object.select_all(action='DESELECT')
                I32.select_set(True)
                I8.view_layer.objects.active = I32
        return {'FINISHED'}

def menu_func_export(I44, I8):
    I44.layout.operator(I1.bl_idname, text='Jenova Hair Data (.jnvhair)')

def register():
    bpy.utils.register_class(I1)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.utils.unregister_class(I1)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
if __name__ == '__main__':
    register()